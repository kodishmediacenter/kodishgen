# -*- coding: utf-8 -*-

import xbmc
import xbmcgui


dialog = xbmcgui.Dialog()
bid = dialog.input('Digite o Codigo do IMDB','', type=xbmcgui.INPUT_ALPHANUM).encode('utf-8').decode('unicode_escape')
    
link = "https://m1.hivid.xyz/d2/HiVid-"+bid+".mp4"
xbmc.Player().play(link)

