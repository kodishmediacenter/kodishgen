chrome.runtime.onInstalled.addListener(() => {
  console.log('Use Kodish instalado.');
});
