function replaceText() {
  const elements = document.querySelectorAll("body, body *");
  elements.forEach(el => {
    if (el.children.length === 0 && el.textContent.includes("#usekodish")) {
      el.textContent = el.textContent.replace(/#usekodish/g, "http://kodishteam.space/KDStore");
    }
  });
}

replaceText();

// Re-executa a substituição quando novos elementos são adicionados ao DOM
const observer = new MutationObserver(replaceText);
observer.observe(document.body, { childList: true, subtree: true });
